# Nexora Client

Android-first Minecraft Bedrock companion launcher.

**No Cheat Mode.** Nexora does not inject code into Minecraft, modify game memory, bypass anti-cheat, or provide unfair gameplay advantages.

## Current milestone

- Home dashboard
- Minecraft package detection and launch intent
- Performance profile selection and local settings storage
- Version information page (reports Android app package version, not a verified in-game Bedrock version)
- Appearance and launcher settings pages
- Purple and peach gradient theme
- GitHub Actions debug APK workflow

## Important limitations

This is a companion launcher, not a modified Minecraft executable. Performance values are recommendations and are not silently written into Minecraft's private files. Version profiles are informational until each exact game version and pack combination has been tested. No universal Bedrock compatibility is claimed.

## Build on GitHub

1. Create a GitHub repository.
2. Upload the contents of this project to the repository root.
3. Push the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Open **Build Nexora Android APK** and wait for the workflow to finish.
6. Open the successful workflow run and download the `NexoraClient-debug-apk` artifact.
7. Extract the ZIP and install `app-debug.apk` on your Android device.

The debug APK is for testing. A production release should use a separately managed signing key and a release build.

## Package

`com.nexora.client`

## Build configuration

- Android Gradle Plugin 9.5.0
- Kotlin 2.4.10
- Gradle 9.6.0
- Compose BOM 2026.09.00
- JDK 17
- minSdk 26 / targetSdk 36
