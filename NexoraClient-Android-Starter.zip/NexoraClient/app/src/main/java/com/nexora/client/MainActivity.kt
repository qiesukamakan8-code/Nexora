package com.nexora.client

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Purple = Color(0xFF8A2BE2)
private val Lavender = Color(0xFFC084FC)
private val Peach = Color(0xFFFFCBA4)
private val Coral = Color(0xFFFF8A65)
private val Background = Color(0xFF100E16)
private val Panel = Color(0xFF211B2B)
private val Panel2 = Color(0xFF2A2236)
private val Muted = Color(0xFFAAA0B8)
private val Good = Color(0xFF55D69E)

private val PurpleGradient = Brush.linearGradient(listOf(Purple, Lavender))
private val PeachGradient = Brush.linearGradient(listOf(Peach, Coral))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexoraApp() }
    }
}

@Composable
private fun NexoraApp() {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("nexora_settings", Context.MODE_PRIVATE)
    }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var page by rememberSaveable { mutableStateOf("Home") }
    var preset by rememberSaveable {
        mutableStateOf(prefs.getString("preset", "Balanced") ?: "Balanced")
    }
    var renderDistance by rememberSaveable {
        mutableFloatStateOf(prefs.getFloat("render_distance", 8f))
    }
    var reduceParticles by rememberSaveable {
        mutableStateOf(prefs.getBoolean("reduce_particles", true))
    }
    var compactHud by rememberSaveable {
        mutableStateOf(prefs.getBoolean("compact_hud", false))
    }
    var launcherAnimations by rememberSaveable {
        mutableStateOf(prefs.getBoolean("animations", true))
    }

    fun saveSettings() {
        prefs.edit()
            .putString("preset", preset)
            .putFloat("render_distance", renderDistance)
            .putBoolean("reduce_particles", reduceParticles)
            .putBoolean("compact_hud", compactHud)
            .putBoolean("animations", launcherAnimations)
            .apply()
    }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lavender,
            secondary = Coral,
            background = Background,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val destinations = listOf(
                        Triple("Home", Icons.Outlined.Home, "Home"),
                        Triple("Performance", Icons.Outlined.Bolt, "Performance"),
                        Triple("Versions", Icons.Outlined.Layers, "Versions"),
                        Triple("Settings", Icons.Outlined.Settings, "Settings")
                    )
                    destinations.forEach { (label, icon, route) ->
                        NavigationBarItem(
                            selected = page == route,
                            onClick = { page = route },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Lavender,
                                indicatorColor = Purple.copy(alpha = 0.30f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF171221), Background, Background)
                        )
                    )
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Header(onSettings = { page = "Settings" })

                when (page) {
                    "Home" -> HomeScreen(
                        context = context,
                        preset = preset,
                        onLaunch = { launchMinecraft(context, ::notify) },
                        onNavigate = { page = it },
                        onNotify = ::notify
                    )
                    "Performance" -> PerformanceScreen(
                        preset = preset,
                        onPreset = { preset = it; saveSettings() },
                        renderDistance = renderDistance,
                        onRenderDistance = { renderDistance = it; saveSettings() },
                        reduceParticles = reduceParticles,
                        onParticles = { reduceParticles = it; saveSettings() },
                        onSave = { saveSettings(); notify("Performance profile saved.") }
                    )
                    "Versions" -> VersionsScreen(context)
                    "Settings" -> SettingsScreen(
                        compactHud = compactHud,
                        onCompactHud = { compactHud = it; saveSettings() },
                        animations = launcherAnimations,
                        onAnimations = { launcherAnimations = it; saveSettings() },
                        onReset = {
                            preset = "Balanced"
                            renderDistance = 8f
                            reduceParticles = true
                            compactHud = false
                            launcherAnimations = true
                            saveSettings()
                            notify("Settings restored to defaults.")
                        }
                    )
                    "Appearance" -> AppearanceScreen(
                        compactHud = compactHud,
                        onCompactHud = { compactHud = it; saveSettings() },
                        animations = launcherAnimations,
                        onAnimations = { launcherAnimations = it; saveSettings() }
                    )
                }

                Text(
                    "NEXORA CLIENT  •  v1.0.0  •  NO CHEAT MODE",
                    color = Muted,
                    fontSize = 9.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                    .background(PurpleGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(25.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("NEXORA", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("BEDROCK CLIENT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
            }
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = Muted)
        }
    }
}

@Composable
private fun HomeScreen(
    context: Context,
    preset: String,
    onLaunch: () -> Unit,
    onNavigate: (String) -> Unit,
    onNotify: (String) -> Unit
) {
    val installed = remember(context) {
        try {
            context.packageManager.getApplicationInfo("com.mojang.minecraftpe", 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("WELCOME BACK", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Text("Ready to play?", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("Your Bedrock setup, in one place.", color = Muted, fontSize = 13.sp)
        }

        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Panel)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(19.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Minecraft Bedrock", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(if (installed) "App detected on this device" else "Minecraft not detected", color = Muted, fontSize = 11.sp)
                    }
                    StatusPill(if (installed) "DETECTED" else "NOT FOUND", installed)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Active profile", color = Muted, fontSize = 12.sp)
                    Text(preset, color = Peach, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }
                GradientButton(
                    text = if (installed) "LAUNCH MINECRAFT" else "CHECK MINECRAFT",
                    brush = PurpleGradient,
                    textColor = Color.White,
                    onClick = onLaunch
                )
                Text("NEXORA IS A COMPANION LAUNCHER. IT DOES NOT MODIFY THE GAME.", color = Muted, fontSize = 9.sp)
            }
        }

        SectionTitle("QUICK ACCESS")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile("FPS Booster", "Tune settings", Icons.Outlined.Bolt, PurpleGradient, Modifier.weight(1f)) {
                onNavigate("Performance")
            }
            QuickTile("Appearance", "HUD options", Icons.Outlined.Palette, PeachGradient, Modifier.weight(1f)) {
                onNavigate("Appearance")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile("Versions", "Compatibility", Icons.Outlined.Layers, PeachGradient, Modifier.weight(1f)) {
                onNavigate("Versions")
            }
            QuickTile("Diagnostics", "Device status", Icons.Outlined.MonitorHeart, PurpleGradient, Modifier.weight(1f)) {
                onNotify("Diagnostics will be added in a later milestone.")
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Panel2)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Outlined.VerifiedUser, contentDescription = null, tint = Good, modifier = Modifier.size(25.dp))
                Column {
                    Text("No Cheat Mode", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("No cheats, hacks, x-ray or unfair advantages.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun PerformanceScreen(
    preset: String,
    onPreset: (String) -> Unit,
    renderDistance: Float,
    onRenderDistance: (Float) -> Unit,
    reduceParticles: Boolean,
    onParticles: (Boolean) -> Unit,
    onSave: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Performance", "Choose a recommended configuration.")
        InfoBanner("These are saved recommendations. Android does not let a normal launcher directly change Minecraft's internal graphics settings.")
        SectionTitle("OPTIMIZATION PROFILE")
        listOf(
            "Quality" to "Prioritize visual detail",
            "Balanced" to "A middle-ground starting point",
            "Performance" to "Reduce optional visual workload",
            "Low-End Device" to "Use conservative settings"
        ).forEach { (name, description) ->
            val selected = preset == name
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onPreset(name) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF332344) else Panel)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(15.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(description, color = Muted, fontSize = 11.sp)
                    }
                    RadioButton(selected = selected, onClick = { onPreset(name) }, colors = RadioButtonDefaults.colors(selectedColor = Lavender))
                }
            }
        }
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Suggested render distance", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("${renderDistance.toInt()} chunks", color = Peach, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = renderDistance,
                    onValueChange = onRenderDistance,
                    valueRange = 4f..16f,
                    steps = 5,
                    colors = SliderDefaults.colors(thumbColor = Peach, activeTrackColor = Lavender)
                )
                SettingRow("Recommend fewer particles", reduceParticles, onParticles)
                Text("This toggle records your preference; it does not silently edit Minecraft files.", color = Muted, fontSize = 10.sp)
            }
        }
        GradientButton("SAVE PROFILE", PeachGradient, Color(0xFF42251F), onSave)
    }
}

@Composable
private fun VersionsScreen(context: Context) {
    val appVersion = remember(context) {
        try {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo("com.mojang.minecraftpe", 0).versionName ?: "Unknown"
        } catch (_: Exception) { null }
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Version Manager", "Inspect the installed game and pack support.")
        InfoBanner("Nexora profile switching changes Nexora settings only. It does not downgrade, reinstall or replace Minecraft.")
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("INSTALLED MINECRAFT APP", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Text(if (appVersion == null) "Not detected" else "App build: $appVersion", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("The Android package version is not necessarily the in-game Bedrock version.", color = Muted, fontSize = 11.sp)
            }
        }
        SectionTitle("COMPATIBILITY PROFILES")
        ProfileInfo("Legacy", "Not validated", "Older game releases; individual pack testing required.")
        ProfileInfo("Stable", "Not validated", "Use only after testing against the exact Bedrock release.")
        ProfileInfo("Latest", "Not validated", "New game updates may change pack and scripting APIs.")
        Text("No universal compatibility claim is made. Unsupported features should be disabled rather than forced.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen(
    compactHud: Boolean,
    onCompactHud: (Boolean) -> Unit,
    animations: Boolean,
    onAnimations: (Boolean) -> Unit,
    onReset: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Settings", "Control the Nexora launcher.")
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SettingRow("Compact HUD preference", compactHud, onCompactHud)
                HorizontalDivider(color = Muted.copy(alpha = 0.15f))
                SettingRow("Launcher animations", animations, onAnimations)
            }
        }
        InfoBanner("HUD preferences are stored locally for the next integration milestone. They do not install or modify a Bedrock pack yet.")
        OutlinedButton(
            onClick = onReset,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Peach)
        ) {
            Icon(Icons.Outlined.RestartAlt, null)
            Spacer(Modifier.width(8.dp))
            Text("RESTORE DEFAULT SETTINGS")
        }
        SectionTitle("ABOUT")
        Text("Nexora Client 1.0.0\nNo Cheat Mode\nAndroid companion launcher", color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun AppearanceScreen(
    compactHud: Boolean,
    onCompactHud: (Boolean) -> Unit,
    animations: Boolean,
    onAnimations: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Appearance", "Minimal controls for the Nexora experience.")
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("COLOR SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(12.dp)).background(PurpleGradient))
                    Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(12.dp)).background(PeachGradient))
                }
                Text("Purple: primary actions. Peach: secondary actions and highlights.", color = Muted, fontSize = 11.sp)
            }
        }
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SettingRow("Compact HUD preference", compactHud, onCompactHud)
                HorizontalDivider(color = Muted.copy(alpha = 0.15f))
                SettingRow("Launcher animations", animations, onAnimations)
            }
        }
        InfoBanner("The actual in-game HUD and resource-pack editor are planned for a later milestone.")
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    brush: Brush,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(brush), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(19.dp))
            }
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun GradientButton(
    text: String,
    brush: Brush,
    textColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(15.dp))
            .background(brush).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = textColor, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun SettingRow(title: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 13.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Purple)
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.3.sp)
}

@Composable
private fun PageHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 27.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun InfoBanner(message: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel2).padding(13.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(Icons.Outlined.Info, null, tint = Peach, modifier = Modifier.size(19.dp))
        Text(message, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun StatusPill(text: String, good: Boolean) {
    Box(
        modifier = Modifier.clip(CircleShape)
            .background((if (good) Good else Coral).copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(text, color = if (good) Good else Coral, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProfileInfo(name: String, status: String, description: String) {
    Card(shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(status, color = Peach, fontSize = 10.sp)
            }
            Text(description, color = Muted, fontSize = 11.sp)
        }
    }
}

private fun launchMinecraft(context: Context, notify: (String) -> Unit) {
    try {
        val intent = context.packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent == null) {
            notify("Minecraft was not found. Install the official game first.")
            return
        }
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        notify("Minecraft could not be opened.")
    } catch (_: SecurityException) {
        notify("Android blocked the launch request.")
    } catch (_: Exception) {
        notify("An unexpected launch error occurred.")
    }
}
